<?php
	# Load and run the test suite as a proper XHTML page
	header("Content-type: application/xhtml+xml");
	readfile("index.html");
?>

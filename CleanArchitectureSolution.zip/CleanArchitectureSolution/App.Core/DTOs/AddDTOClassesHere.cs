﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTOs
{
    public class AddDTOClassesHere
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Repositories
{
    public class AddRepositoryClassesHere
    {
    }
}
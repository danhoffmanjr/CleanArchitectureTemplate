﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Services
{
    public class AddServiceClassesHere
    {
    }
}